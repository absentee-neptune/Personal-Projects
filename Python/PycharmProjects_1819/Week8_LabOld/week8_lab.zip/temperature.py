"""Classes for working with Temperatures.

Author: Brianna Guest
Class: CSI-260-02
Assignment: Week 8 Lab
Due Date: March 17, 2019 11:59 PM

Certification of Authenticity:
I certify that this is entirely my own work, except where I have given
fully-documented references to the work of others. I understand the definition
and consequences of plagiarism and acknowledge that the assessor of this
assignment may, for the purpose of assessing this assignment:
- Reproduce this assignment and provide a copy to another member of academic
- staff; and/or Communicate a copy of this assignment to a plagiarism checking
- service (which may then retain a copy of this assignment on its database for
- the purpose of future plagiarism checking)
"""

NUMBERS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
LETTERS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
           'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
           'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd',
           'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
           'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
           'y', 'z']


class TemperatureError(Exception):
    """Raises Error if degrees is not one of the specified forms."""
    def __init__(self, degrees):
        """Initialize exception with given username.

        Can optionally provide a user instance as well.
        """
        super().__init__(degrees)
        self.degrees = type(degrees)

    def __str__(self):
        return f'Invalid Value: {self.degrees}'


class Temperature:
    """Represents a temperature.

    Temperatures are expressable in degrees Fahrenheit, degrees Celsius,
    or Kelvins.
    """

    def __init__(self, degrees=0):
        """Initialize temperature with specified degrees.

        Args:
            degrees, which can be one of the following:
                (1) a number, or a string containing a number
                    in which case it is interpreted as degrees Celsius
                (2) a string containing a number followed by one of the
                    following symbols:
                       C, in which case it is interpreted as degrees Celsius
                       F, in which case it is interpreted as degrees Fahrenheit
                       K, in which case it is interpreted as Kelvins

        Raises:
            InvalidTemperatureError: if degrees is not one of the specified
                                     forms

        """
        if type(degrees) is not str:
            try:
                self.celsius = float(degrees)
            except ValueError or AttributeError or TypeError:
                raise TemperatureError(type(degrees))
        elif type(degrees) is str:
        #     degrees_celsius = degrees.endswith('C')
        #     degrees_fahrenheit = degrees.endswith('F')
        #     degrees_kelvin = degrees.endswith('K')
        #     if degrees_celsius is True:
        #         self.celsius = float(degrees[:-1])
        #     elif degrees_fahrenheit is True:
        #         fahrenheit = float(degrees[:-1])
        #         self.celsius = ((fahrenheit - 32) * (5/9))
        #     elif degrees_kelvin is True:
        #         kelvin = float(degrees[:-1])
        #         self.celsius = (kelvin - 273.15)
            if degrees[-1] == 'C':
                self.celsius = float(degrees[:-1])
            elif degrees[-1] == 'F':
                fahrenheit = float(degrees[:-1])
                self.celsius = ((fahrenheit - 32) * (5/9))
            elif degrees[-1] == 'K':
                kelvin = float(degrees[:-1])
                self.celsius = (kelvin - 273.15)
            elif degrees in NUMBERS:
                self.celsius = float(degrees)
            elif (degrees[0] in LETTERS) or (degrees[-1] != 'C'):
                raise TemperatureError(degrees)

    @property
    def celsius(self):
        return self.celsius

    @celsius.setter
    def celsius(self, celsius):
        self.degrees = celsius

    @property
    def fahrenheit(self):
        return (self.celsius * (9/5)) + 32

    @fahrenheit.setter
    def fahrenheit(self, fahrenheit):
        self.degrees = fahrenheit

    @property
    def kelvin(self):
        return self.celsius + 273.15

    @kelvin.setter
    def kelvin(self, kelvin):
        self.degrees = kelvin

    @classmethod
    def average(cls, temperatures):
        """Compute the average of a list of temperatures.

        Args:
            temperatures: a list of Temperature objects
        Returns:
            a Temperature object with average (mean) of the given temperatures

        """
        pass
